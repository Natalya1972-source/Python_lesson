class GroupLimitError(Exception):
    pass