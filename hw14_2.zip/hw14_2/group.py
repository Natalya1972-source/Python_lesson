from exceptions import GroupLimitError
from student import Student


class Group:
    def __init__(self, number):
        self.number = number
        self.group = set()

    def add_student(self, student: Student):
        # не додаємо дублікат
        if student in self.group:
            return

        # ліміт 10
        if len(self.group) >= 10:
            raise GroupLimitError("Cannot add more than 10 students")

        self.group.add(student)

    def find_student(self, last_name: str):
        last_name = last_name.strip().lower()
        for student in self.group:
            if student.last_name.strip().lower() == last_name:
                return student
        return None

    def delete_student(self, last_name: str):
        student = self.find_student(last_name)
        if student is not None:
            self.group.remove(student)

    def __str__(self):
        all_students = ''
        for student in self.group:
            all_students += str(student) + '\n'
        return f'Number:{self.number}\n{all_students}'